package com.example.submission_pertama

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
